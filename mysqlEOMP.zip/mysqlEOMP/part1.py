from tkinter import *
import mysql.connector
from tkinter import messagebox
import datetime

window1 = Tk()
window1.title("Main Page")
window1.geometry("800x500")

# First tkinter window that pops up to select login or close program
window1.bind('<a>', lambda z: admin_login())

def admin_login():
    window2 = Tk()
    window2.title("Admin Login")
    window2.geometry("400x210")

    mydb2 = mysql.connector.connect( user='lifechoices',password='@Lifechoices1234',host='127.0.0.1',
                                     database='lifechoicesonline',auth_plugin='mysql_native_password')

    mycursor2 = mydb2.cursor()
    window1.destroy()


    def login():
        a = admin_entry_user.get()
        b = admin_entry_user2.get()
        sql2 = "INSERT INTO Admin_Login VALUES (%s, %s)"
        mycursor2.execute(sql2, [(a), (b)])
        mydb2.commit()
        window2.destroy()
# Register window

    def reg():
        window3 = Tk()
        window3.title("Register Page")
        window3.geometry("247x250")

        mydb2 = mysql.connector.connect( user='lifechoices',
                                        password='@Lifechoices1234',host='127.0.0.1', database='lifechoicesonline',
                                        auth_plugin='mysql_native_password')

        mycursor2 = mydb2.cursor()

        date_time = datetime.datetime.now()
        lbl_date = Label(window3, text=date_time)
        lbl_date.grid(row=10, column=1)

# function to insert registered data into database table

        def registered():
            a = id_entry.get()
            b = name_entry.get()
            c = user_entry.get()
            d = pass_entry.get()
            sql2 = "INSERT INTO Register VALUES (%s, %s, %s, %s)"
            mycursor2.execute(sql2, [int(a), (b), (c), (d)])
            mydb2.commit()
            messagebox.showinfo("Congrats", "You Are Registered")
            file_write = open("textfile.txt", "a+")
            file_write.write("Name and Surname: " + str(name_entry.get()) + "\n")
            file_write.write("Username: " + user_entry.get() + "\n")
            file_write.write("Password: " + str(pass_entry.get()) + "\n")
            file_write.write("ID Number: " + (id_entry.get()) + "\n")
            file_write.write("Time and Date: " + str(date_time) + "\n" + "\n")
            file_write.close()
            window3.destroy()

        id_number = Label(window3, text="ID Number")
        id_number.grid(row=1, column=1)
        id_entry = Entry(window3, width=30)
        id_entry.grid(row=2, column=1)

        name_lbl = Label(window3, text="Full Names and Surname")
        name_lbl.grid(row=3, column=1)
        name_entry = Entry(window3, width=30)
        name_entry.grid(row=4, column=1)

        user_name = Label(window3, text="Create Username")
        user_name.grid(row=5, column=1)
        user_entry = Entry(window3, width=30)
        user_entry.grid(row=6, column=1)

        password = Label(window3, text="Create Password")
        password.grid(row=7, column=1)
        pass_entry = Entry(window3, width=30)
        pass_entry.grid(row=8, column=1)

        reg_button = Button(window3, text="Register", command=registered)
        reg_button.grid(row=9, column=1)

        window3.mainloop()

# window to view all registered users

    def view_reg():
        window5 = Tk()
        window5.title("Registered Users")
        window5.geometry("665x400")

        mydb2 = mysql.connector.connect( user='lifechoices',
                                        password='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline',
                                        auth_plugin='mysql_native_password')

        mycursor2 = mydb2.cursor()

        mycursor2.execute("SELECT * FROM Register")
        results = mycursor2
        i = 0
        if results:
            for x in results:
                for v in range(len(x)):
                    e = Entry(window5, width=20)
                    e.grid(row=i, column=v)
                    e.insert(END, x[v])
                i = i + 1

        def close():
            window5.destroy()

# function to delete registered users from table

        def delete():
            mycursor2.execute("TRUNCATE TABLE Register")
            messagebox.showinfo("Delete", "All Registered Users Deleted")
            window5.destroy()

        remv_button = Button(window5, text="Remove", command=delete)
        remv_button.grid(row=16, columnspan=7)

        window5.mainloop()

    def new_login():
        window4 = Tk()
        window4.title("Admin")
        window4.geometry("800x500")

        admin_lbl = Label(window4, text="Welcome To Life Choices Online")
        admin_lbl.pack()

        regbtn = Button(window4, text="Register Users", command=reg)
        regbtn.pack()

        viewbtn = Button(window4, text="View Registered Users", command=view_reg)
        viewbtn.pack()

        window4.mainloop()

    all_commands = lambda: [login(), new_login()]

    label_user = Label(window2, text='Enter Username')
    label_user.pack()
    admin_entry_user = Entry(window2, width=30)
    admin_entry_user.pack()

    label_user2 = Label(window2, text='Enter Password')
    label_user2.pack()
    admin_entry_user2 = Entry(window2, width=30)
    admin_entry_user2.pack()

    loginbtn = Button(window2, text='Login', command=all_commands)
    loginbtn.pack()

    window2.mainloop()

# exit function to close windows


def exit1():
    window1.destroy()

lbl1 = Label(window1, text="Lifechoices Online", font=('ariel',20))
lbl1.pack()

btn1 = Button(window1, text="Login", command=admin_login)
btn1.place(x=335, y=200)

btn3 = Button(window1, text="Exit", command=exit1)
btn3.place(x=400, y=200)

window1.mainloop()
